# amazon clone
 amazon
